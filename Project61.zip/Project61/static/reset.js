function reset1(){
  var container = document.getElementById("time1");
  container.innerHTML= html;
}                
var html;
window.onload = function(){
html = document.getElementById('time1').innerHTML;
};         