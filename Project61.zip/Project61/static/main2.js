document.getElementById("viewtb").addEventListener("click", function () {

  fetch('/getdata')
    .then(response => response.json())
    .then(data => {
      data.forEach(row => {
        var Stime = row.stime
        var Time = row.time
        var Venue = row.venue
        var Course = row.course
        var Ccolor = row.c_color
        var Whichday = row.whichday
        var Faculty = row.faculty

        var div = document.createElement("span");
        div.style.padding = "10px"

        var node = document.createElement("span");
        var textnode = document.createTextNode(Course);
        node.appendChild(textnode);
        node.style.fontSize = "22px"
        div.appendChild(node);


        var node1 = document.createElement("span");
        var textnode1 = document.createTextNode(" " + Venue);
        node1.appendChild(textnode1);
        node1.style.fontSize = "19px"
        div.appendChild(node1);

        let node2 = document.createElement("p");
        let textnode2 = document.createTextNode(Faculty);
        node2.appendChild(textnode2);
        node2.style.fontSize = "15px"
        div.appendChild(node2);
        stime = Number(Stime)
        time = Number(Time)
        i = Number(idmanager[Whichday])

        //Check a element is present on adjacent or same place.

        div.id = day[0] + i
        div.style.position = "absolute";
        div.className += day
        div.style.background = Ccolor;
        div.style.marginTop = stime * 75 + "px";
        div.style.height = time * 75 + "px";
        document.getElementById(Whichday).appendChild(div);
        document.getElementById("iclose").click();

      });
    });
});